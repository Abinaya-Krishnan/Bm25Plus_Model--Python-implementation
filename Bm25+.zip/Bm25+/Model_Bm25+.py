import math
from porter2 import stem

def avg_doc_len(coll):
    tot_dl = 0
    for id, doc in coll.get_docs().items():
        tot_dl = tot_dl + doc.get_doc_len()
    return tot_dl / coll.get_num_docs()


def bm25(coll, q, df):
    bm25s = {}
    avg_dl = avg_doc_len(coll)
    no_docs = coll.get_num_docs()
    for id, doc in coll.get_docs().items():
        query_terms = q.split()
        qfs = {}
        for t in query_terms:
            term = stem(t.lower())
            try:
                qfs[term] += 1
            except KeyError:
                qfs[term] = 1
        k = 1.2 * ((1 - 0.75) + 0.75 * (doc.get_doc_len() / float(avg_dl)))
        bm25_ = 0.0;
        for qt in qfs.keys():
            n = 0
            if qt in df.keys():
                n = df[qt]
                f = doc.get_term_count(qt);
                delta = 1
                qf = qfs[qt]
                bm = math.log(1.0 / ((n) / (no_docs+1)), 2) * ((((1.2 + 1) * f) / (k + f) )+ delta)
                bm25_ += bm
        bm25s[doc.get_docid()] = bm25_
    return bm25s


if __name__ == "__main__":

    import sys
    import os
    import coll
    import df

    training_document = ""
    query = ""

    inputText = open('TopicStatements101-150.txt', 'r')
    top = 0
    flag = 0
    for line in inputText.readlines():
        if flag != 1:
            if line.startswith("<top>"):
                query = ""
                top = 1
            if line.startswith("<num"):
                training_document = line[15:]
                training_document = training_document[:3]
            elif line.startswith("</top"):
                flag = 0
            else:
                if line.startswith("<title"):
                    query = line[7:]
                    flag = 1  # extra

        if flag == 1:
            flag = 0
            coll_fname = ".\Training_set\Training" + training_document

            stopwords_f = open('common-english-words.txt', 'r')
            stop_words = stopwords_f.read().split(',')
            stopwords_f.close()
            coll_ = coll.parse_rcv_coll(coll_fname, stop_words)
            df_ = df.calc_df(coll_)
            bm25_1 = bm25(coll_, query, df_)
            print('For query ' + "\\" + query + "\" ")

            os.chdir('..')
            os.chdir('..')
            wFile = open('WSMModel_R' + training_document + '.dat', 'a')  # change output for all documents

            for (k, v) in sorted(bm25_1.items(), key=lambda x: x[1], reverse=True):
                wFile.write(k + ' ' + str(v) + '\n')
            wFile.close()


            writeFile = open('Bm25PlusTraining_benchmark' + training_document + '.txt', 'a')

            datFile = open('WSMModel_R' + training_document + '.dat')
            file_ = datFile.readlines()
            for line in file_:
                line = line.strip()
                lineStr = line.split()
                if float(lineStr[1]) > 1:  # significance of >1?
                    #
                    #
                    writeFile.write('R' + training_document + ' ' + lineStr[0] + ' 1' + '\n')
                else:
                    writeFile.write('R' + training_document + ' ' + lineStr[0] + ' 0' + '\n')
            writeFile.close()
            datFile.close()




import glob, os
import string

def task1(inputpath,i,count):
    coll = {}

    A = {}
    B = {}
    R1 = {}
    R2 = {}

    for line in open("./Topicassignment101-150/Training" + str(i)+ ".txt"):
        line = line.strip()
        line1 = line.split()
        A[line1[1]] = int(float(line1[2]))
    for line in open("./result" + str(count) + ".dat"):
        line = line.strip()
        line1 = line.split()
        B[line1[0]] = int(float(line1[1]))
    return (A, B)


if __name__ == '__main__':
    import sys

    i = 101
    count = 1
    d = 0
    precision = [0] * 51
    recall = [0] * 51
    ff1 = [0] * 51
    precision[0] = 0.0
    temp_p = {}
    temp_r = {}
    temp_f = {}
    temp_topic = {}
    meanrecall = 0
    while i <= 150:

        (rel_doc, retrived_doc) = task1(os.getcwd(), i, count)

        sortedBM25 = {k: v for k, v in sorted(rel_doc.items(),
                                              key=lambda item: item[1], reverse=True)}

        temp = {}

        for items1, keys1 in sortedBM25.items():
            temp.update({items1: 0})
            for items, keys in retrived_doc.items():
                if items == items1:
                    temp.update({items1: 1})
                    break

        R = 0
        for (x, y) in rel_doc.items():
            if (y == 1):
                R = R + 1

        R1 = 0
        for (x, y) in temp.items():
            if (y == 1):
                R1 = R1 + 1


        RR1 = 0
        for (x, y) in rel_doc.items():
            if (y == 1) & (temp[x] == 1):
                RR1 = RR1 + 1

        r = float(RR1) / float(R)

        if R1 != 0:
            p = float(RR1) / float(R1)
        else:
            p = 0

        if p + r != 0:
            F1 = 2 * p * r / (p + r)
        else:
            F1 = 0

        temp_p[count] = p
        temp_r[count] = r
        temp_f[count] = F1
        temp_topic[count] = i
        meanrecall += r
        i = i + 1
        count = count + 1
        d = d + 1

if count == 51:
    sortedprecision = {k: v for k, v in sorted(temp_p.items(),
                                               key=lambda item: item[1], reverse=True)}

    sortedrecall = {k: v for k, v in sorted(temp_r.items(),
                                            key=lambda item: item[1], reverse=True)}
    sortedfmeasure = {k: v for k, v in sorted(temp_f.items(),
                                              key=lambda item: item[1], reverse=True)}
    k = 0
    g = 0
    wFile = open('EvaluationResult.dat', 'w')
    wFile.write('{:<6s}{:<25s}{:<25s}{:<25s}'.format("TOPIC", "PRECISION", "RECALL", "F1"))
    print('{:<6s}{:<25s}{:<25s}{:<25s}'.format("TOPIC", "PRECISION", "RECALL", "F1"))
    for i, j in sortedprecision.items():
        if (k < 10):
            k = k + 1
            wFile.write('\n')
            wFile.write('{:<6s}{:<25s}{:<25s}{:<25s}'.format(str(temp_topic[i]), str(j), str(sortedrecall[i]),
                                                             str(sortedfmeasure[i])))

        if (g < 50):
            print('{:<6s}{:<25s}{:<25s}{:<25s}'.format(str(temp_topic[i]), str(j), str(sortedrecall[i]),
                                                       str(sortedfmeasure[i])))

    print("Mean recall", meanrecall / 50)
    wFile.close()

